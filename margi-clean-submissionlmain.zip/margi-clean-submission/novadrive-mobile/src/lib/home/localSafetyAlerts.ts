export function haversineKm(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

export function filterAlertsWithinKm<T extends { lat: number; lng: number }>(
  alerts: T[],
  lat: number,
  lng: number,
  radiusKm = 5
): T[] {
  return alerts.filter((a) => haversineKm(lat, lng, a.lat, a.lng) <= radiusKm);
}
